import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class screensaver_variety extends PApplet {

Spin s;
Runzig z;
Ball b;
RandomCurve rc;
Species speci;
String state = "spin";
float randDirX, randDirY;
boolean modeSame=false;
String mode;

public void setup()
{
  noCursor();
  
  s = new Spin();
  z = new Runzig();
  b = new Ball();
  rc = new RandomCurve();
  speci = new Species();
  restart();
}

public void draw()
{
  if(state == "curve")
  {
    if(frameCount>2000)
    {
      restart();
    }else
    {
      rc.tick();
    }
  }else if (state == "microbes")
  {
    if (frameCount>1000)
    {
      restart();
    }else
    {
      speci.tick();
    }
  } else if (state == "spin")
  {
    if (s.isfast)
    {
      if(s.angle>1800)
      {
        restart();
      }else
      {
        s.ontick();
      }
    } else
    {
      if (s.angle>180)
      {
        restart();
      }else
      {
        s.ontick();
      }
    }
  } else if (state == "ball")
  {
    if (frameCount>1000)
    {
      background(0);
      frameCount=0;
      restart();
    }else
    {
      b.ontick();
    }
  } else
  {
    if (frameCount>2000)
    {
      background(0);
      frameCount=0;
      restart();
    }else
    {
      z.draw_zig();
    }
  }
}

public void mouseReleased()
{
  restart();
}
public void keyReleased()
{
  restart();
}

public void restart()
{
  background(0);
  frameCount=0;
  if(random(10)>7)
  {
    state = "curve";
    rc.reset();
  }else if (random(1) > 0.8f)
  {
    state = "microbes";
    speci.reset();
  } else if (random(1) >0.5f)
  {
    state = "spin";
    s.reset();
    s.start_spin();
  } else if (random(1)>0.3f)
  {
    state = "zig";
    z.reset();
  } else
  {
    state = "ball";
    b.reset();
  }
}
class Ball
{
  float maxspeedb = width/8;
  float xb, yb, colormode, xspeedb, yspeedb, thickness;
  int c;
  Ball()
  {
  }

  public void reset()
  {
    xspeedb = random(2, maxspeedb);
    yspeedb = random(2, maxspeedb);
    thickness = random(5, 30);
    xb = random(thickness, width-thickness);
    yb = random(thickness, height-thickness);
    c = color(random(0, 255), random(0, 255), random(0, 255));
  }

  public void ontick()
  {
    strokeWeight(thickness);
    stroke(c);
    float oldxb = xb;
    float oldyb = yb;
    xb += xspeedb;
    yb += yspeedb;
    if (xb+(thickness/2)>=width)
    {
      xspeedb = -abs(xspeedb);
      yb = random(oldyb-abs(xspeedb*3), oldyb+abs(xspeedb*3));
      xb = width-thickness/2;
    }
    if (xb-thickness/2<=0)
    {
      xspeedb = abs(xspeedb);
      yb = random(oldyb-abs(xspeedb*3), oldyb+abs(xspeedb*3));
      xb = thickness/2;
    }
    if (yb+thickness/2>=height)
    {
      yspeedb = -abs(yspeedb);
      yb = height-thickness/2;
      xb = random(oldxb-abs(yspeedb*3), oldxb+abs(yspeedb*3));
    }
    if (yb-thickness/2<=0)
    {
      yspeedb = abs(yspeedb);
      yb = thickness/2;
      xb = random(oldxb-abs(yspeedb*3), oldxb+abs(yspeedb*3));
    }
    
    //then check again just in case it bounced out
    if (xb+(thickness/2)>=width)
    {
      xb = width-thickness/2;
    }
    if (xb-thickness/2<=0)
    {
      xb = thickness/2;
    }
    if (yb+thickness/2>=height)
    {
      yb = height-thickness/2;
    }
    if (yb-thickness/2<=0)
    {
      yb = thickness/2;
    }
    line(oldxb, oldyb, xb, yb);
  }
}
class ChangeColor
{
  int colorchanging;
  int c;

  ChangeColor()
  {
    c = color(random(0, 255), random(0, 255), random(0, 255));
  }

  public void tick()
  {
    if(random(100)>99)
    {
      colorchanging = PApplet.parseInt(random(3));
    }
    
    if (colorchanging == 0)
    {
      c = color((red(c)+1)%255, green(c), blue(c));
    } else if (colorchanging == 1)
    {
      c = color(red(c), (green(c)+1)%255, blue(c));
    } else
    {
      c = color(red(c), green(c), (blue(c)+1)%255);
    }
    stroke(c);
  }
}


/*
Class written to represent L-Systems https://en.wikipedia.org/wiki/L-system

L-Systems consist of a set of rules of how symbols in a starting string referred
to as the axiom are replaced.

The special symbols are:

F --- draw forward one length
f --- move forward one length
+ --- turn counterclockwise one angle worth
- --- turn clockwise one angle worth
[ --- store the current position and angle
] --- restore the position and angle stored at the matching angle bracket

*/
class LSystem {
  String structure;
  
  // Set of production rules
  HashMap<Character, String> rules;
  
  // Angle of turns on + and - symbols
  float angle;
  
  // Store the positions and angles stored by [
  Stack<PVector> posStack;
  Stack<PVector> stepStack;
  
  // State variables for drawing the L-System
  PVector pos;
  PVector step;
  int structI;
  
  LSystem(String axiom, HashMap<Character, String> rules, float angle) {
    structure = axiom;
    this.rules = rules;
    this.angle = angle;
    
    posStack = new Stack<PVector>();
    stepStack = new Stack<PVector>();
  }
  
  // Each time step is called, each character with a production rule is replaced with
  // its production.
  public void step() {
    StringBuilder next = new StringBuilder();
    
    for(int i = 0; i < structure.length(); i++) {
      char curr = structure.charAt(i);
      if(rules.containsKey(curr)) {
        next.append(rules.get(curr));
      }
      else {
        next.append(curr);
      }
    }
    
    structure = next.toString();
  }
  
  // Runs step n times
  public void step(int n) {
    for(int i = 0; i < n; i++) {
      step();
    }
  }
  
  // Sets up the position and length of line segments for stepRender.
  public void initStepRender(int x, int y, float len) {
    pos = new PVector(x, y);
    step = new PVector(len, 0);
    structI = 0;
  }
  
  // Each time this is called, a single line segment of the L-System is drawn.
  // Returns true when the L-System is finished drawing.
  public boolean stepRender() {
    if(structI >= structure.length()) {
      return false;
    }
    
    boolean drew = false;
    
    char sym = structure.charAt(structI);
    if(sym == 'F') {
      PVector next = PVector.add(pos, step);
      line(pos.x, pos.y, next.x, next.y);
      pos = next;
      drew = true;
    }
    else if(sym == 'f') {
      pos.add(step);
    }
    else if(sym == '+') {
      step.rotate(angle);
    }
    else if(sym == '-') {
      step.rotate(-angle);
    }
    else if(sym == '[') {
      posStack.push(new PVector(pos.x, pos.y));
      stepStack.push(new PVector(step.x, step.y));
    }
    else if(sym == ']') {
      pos = posStack.pop();
      step = stepStack.pop();
    }
    
    structI++;
    
    if(pos.x<0)
    {
      pos.x = width;
    }
    if(pos.y < 0)
    {
      pos.y = height;
    }
    if(pos.y>height)
    {
      pos.y = 0;
    }
    if(pos.x > width)
    {
      pos.x = 0;
    }
    
    if(drew) {
      return true;
    }
    else {
      //return stepRender();
      return true;
    }
  }
  
  // Draw the entire L-System at once
  public void render(int x, int y, int len) {
    initStepRender(x, y, len);
    while(stepRender());
  }
}
public class Microbe
{
  float radius;
  float x;
  float y;
  boolean isalive;
  int c;
  
  Microbe(float xt, float yt, int ct)
  {
    x = xt;
    y = yt;
    isalive = true;
    c = ct;
    radius = random(width/25, width/15);
  }
  
  public void tick()
  {
    fill(c);
    rect(x, y, radius*2, radius*2);
    radius *= 0.992f;
  }
}
class RandomCurve
{
  LSystem ls;
  ChangeColor change = new ChangeColor();
  int speed;

  RandomCurve()
  {
  }

  public void tick() {
    for (int x = 0; x<speed-1; x++)
    {
      change.tick();
      ls.stepRender();
    }
    if (!ls.stepRender())
    {
      reset();
    }
  }

  public void reset()
  {
    clear();
    strokeWeight(1);
    speed = PApplet.parseInt(random(10, 20));
    //generate a random curve
    String axiom;
    HashMap<Character, String> rules = new HashMap<Character, String>();
    float angle = radians(90);
    if (random(10)>8)
    {
      angle = radians(random(20, 340));
    }
    axiom = "1";
    int rulelen = PApplet.parseInt(random(2, 15));
    if (random(1)>0.4f)
    {
      rulelen = PApplet.parseInt(random(2, 4));
    }
    String rule = "";
    float angledelta = 0;
    int calls = 0;

    for (int x = 0; x<rulelen; x++)
    {
      if (random(1)>0.5f)
      {
        rule = rule + "+";
        angledelta+= - angle;
        if (random(1)>0.5f)
        {
          rule = rule + "+";
          angledelta += -angle;
        }
      } else
      {
        rule = rule + "-";
        angledelta+=angle;
        if (random(1)>0.5f)
        {
          rule = rule + "-";
          angledelta += angle;
        }
      }
      if (calls<2)
      {
        if (random(0, rulelen-x)<1)
        {
          calls++;
          rule = rule + "1";
        }
      }
      if (random(1)>0.7f)
      {
        rule = rule + "F";
      } else
      {
        rule = rule + "f";
      }
    }

    //if (random(1)>0.5)
    //{
    //  int firstplace = int((random(0, rule.length()-2)));
    //  int secondplace = int(random(firstplace+2, rule.length()));

    //  rule = rule.substring(0, firstplace) + "[" + rule.substring(firstplace, rule.length());
    //  rule = rule.substring(0, secondplace+1) + "]" + rule.substring(secondplace+1);
    //}
    //if (random(10)>9)
    //{
    //  int firstplace = int((random(0, rule.length()-1)));
    //  int secondplace = int(random(firstplace+1, rule.length()));

    //  rule = rule.substring(0, firstplace) + "[" + rule.substring(firstplace, rule.length());
    //  rule = rule.substring(0, secondplace+1) + "]" + rule.substring(secondplace+1);
    //}

    angledelta = angledelta%radians(360);

    //if (angledelta <= angle && angledelta >= -angle)
    //{
    //  if (angledelta + angle > angle)
    //  {
    //    rule = "--"+rule;
    //  } else if (angledelta -angle < angle)
    //  {
    //    rule = "++"+rule;
    //  }
    //}

    axiom = "-A";
    ls = new LSystem(axiom, rules, angle);
    ls.initStepRender(width/2, height/2, random(6, 12));
    if (random(10)<8)
    {
      rules.put('A', "FA-1+FA+");
      rules.put('1', rule);
    } else
    {
      angle = radians(90);
      rule = "[+"+randomBranch()+"A]["+randomBranch()+"A][-"+randomBranch()+"A]";
      rules.put('A', rule);
      if (random(10)>8)
      {
        rules.put('F', "ff");
        rules.put('f', "FF");
      } else
      {
        rules.put('F', "ff");
        rules.put('f', "ff");
      }
    }

    while (ls.structure.length()<30000)
    {
      ls.step();
    }
  }

  public String randomBranch()
  {
    int num = PApplet.parseInt(random(1, 4));
    String s = "";
    for (int x=0; x<num; x++)
    {
      if (random(1)>0.5f)
      {
        s = s + "F";
      } else
      {
        s = s + "f";
      }
    }
    return s;
  }
}
class Runzig
{
  //Oliver Flatt
  int numOfZigs;
  Zig[] zigs = new Zig[50];

  Runzig()
  {
  }

  public void randomRandomMode()
  {
    if (PApplet.parseInt(random(0, 2))==1)
    {
      modeSame=false;
      mode=randomMode();
      modeSame=true;
    } else
    {
      modeSame=false;
    }
  }

  public String randomMode()
  {
    int r=PApplet.parseInt(random(0, 4));
    if (modeSame)
    {
      return mode;
    } else
    {
      if (r==1)
      {
        return "original";
      } else if (r==3)
      {
        return "square";
      } else if (r==2)
      {
        return "smooth";
      } else
      {
        return "zig-zag";
      }
    }
  }

  public void draw_zig()
  {
    int i = 0;
    while (i<numOfZigs)
    {
      zigs[i].drawOne();
      i++;
    }
  }

  public void reset()
  {
    background(0);
    randomRandomMode();
    numOfZigs = PApplet.parseInt(random(1, 30));
    int i=0;
    while (i<numOfZigs)
    {
      randomDir(-10, 10, 1);
      float squarewidth = random(10, width/5);
      if (random(5)>1)
      {
        squarewidth = random(10, 30);
      }
      float thickness = random(0, 20);
      if(random(5)>1) {
        thickness = random(0, 4);
      }
      zigs[i] = new Zig(random(10, displayWidth-10), 
        random(10, displayHeight-10), 
        randDirX, 
        randDirY, 
        randomMode(), 
        thickness, 
        color(random(0, 255), random(0, 255), random(0, 255)),
        squarewidth);
      i++;
    }
  }
}
class Species
{
  Microbe population[];
  int current_population = 1;
  int max = 900;

  Species()
  {
  }

  public void tick()
  {
    clear();
    int x = 0;
    while (x < current_population)
    {
      if (population[x].isalive)
      {
        population[x].tick();
        //if it dies
        if(population[x].radius < width/100)
        {
          population[x].isalive = false;
        }
        if(random(100)<1)
        {
          float newx;
          float newy;
          if(random(1)>0.5f)
          {
            newx = random((population[x].x - width/10), (population[x].x - width/20));
          }else
          {
            newx = random((population[x].x + width/20), (population[x].x + width/10));
          }
          if(random(1)>0.5f)
          {
            newy = random((population[x].y - width/10), (population[x].y - width/20));
          }else
          {
            newy = random((population[x].y + width/20), (population[x].y + width/10));
          }
          if(newx>width)
          {
            newx = -newx;
          }
          if(newx<0)
          {
            newx = -newx;
          }
          if(newy<0)
          {
            newy = -newy;
          }
          if(newy>height)
          {
            newy = -newy;
          }
          int newc = population[x].c;
          if(random(1) < 1/3)
          {
            newc = color((red(newc)+15)%255, green(newc), blue(newc));
          }else if(random(1)>0.5f)
          {
            newc = color(red(newc), (green(newc)+15)%255, blue(newc));
          }else
          {
            newc = color(red(newc), green(newc), (blue(newc)+15)%255);
          }
          Microbe thenew = new Microbe(newx, newy, newc);
          population[current_population] = thenew;
          current_population++;
          if (current_population == max)
          {
            reset();
          }
        }
      }
      x++;
    }
  }
  
  public void reset()
  {
    clear();
    rectMode(CENTER);
    stroke(0);
    strokeWeight(1);
    population = new Microbe[max];
    current_population = 2;
    int randc = color(random(0, 255), random(0, 255), random(0, 255));
    population[0] = new Microbe(random(width/20, width-(width/20)), random(width/20, height-width/20), randc);
    population[1] = new Microbe(random(width/20, width-(width/20)), random(width/20, height-width/20), randc);
  }
}
class Spin
{
  float angle = 0;
  int colormode = 0;
  float rectanglewidth, rectangleheight, ellipseheight, ellipsewidth;
  boolean drawtriangle, drawrect, drawellipse;
  float trix1, trix2, triy1, triy2;
  float widthfactor, heightfactor;
  int tricolormode, rectcolormode, ellipsecolormode;
  float resettime;
  float animationspeedfactor;
  float rectotherc, triotherc, ellipseotherc;
  float rectcolorchangefactor, tricolorchangefactor, ellipsecolorchangefactor;
  int numofloop = 25;
  boolean iswhite = false;
  int backgroundc = 0;
  float translatex, translatey, translatedirx, translatediry, tspeed;
  float greatestwidth;
  boolean isfast;
  boolean isoffset;

  Spin()
  {
  }

  public void start_spin()
  {
    rectMode(CENTER);
    noFill();
    translatex = width/2;
    translatex = width/2;
    translatey = height/2;
    tspeed = 5;
    strokeWeight(1);
    reset();
  }

  public void ontick()
  {
    float dt = millis() - resettime;
    background(backgroundc);
    if (!isoffset)
    {
      movetranslate();
    }
    translate(translatex, translatey);
    int x = 0;
    float widths = 1;
    float heights = 1;
    float o;
    if(isoffset)
    {
      o = width/10;
    }else
    {
      o = 0;
    }
    while (x < numofloop)
    {
      rotate(radians(angle));
      if (drawrect)
      {
        strokefactorandmode(x, rectcolormode, rectotherc, rectcolorchangefactor);
        rect(o, o, rectanglewidth*widths, rectangleheight*heights);
      }
      if (drawellipse)
      {
        strokefactorandmode(x, ellipsecolormode, ellipseotherc, ellipsecolorchangefactor);
        ellipse(o, o, ellipsewidth*widths, ellipseheight*heights);
      }
      if (drawtriangle)
      {
        strokefactorandmode(x, tricolormode, triotherc, tricolorchangefactor);
        triangle(o, o, trix1*widths, triy1*heights, trix2*widths, triy2*heights);
      }
      widths *= widthfactor;
      heights *= heightfactor;
      x++;
    }
    angle = (dt/1000)*animationspeedfactor;
  }

  public void movetranslate()
  {
    translatex += translatedirx;
    translatey += translatediry;
    if (translatex + greatestwidth/2 > width)
    {
      translatedirx = -translatedirx;
    }
    if (translatex - greatestwidth/2 < 0)
    {
      translatedirx = -translatedirx;
    }
    if (translatey + greatestwidth/2 > height)
    {
      translatediry = -translatediry;
    }
    if (translatey - greatestwidth/2 < 0)
    {
      translatediry = -translatediry;
    }
  }

  public void reset()
  {
    if (random(10)>7)
    {
      isoffset = true;
    } else
    {
      isoffset = false;
    }
    translatedirx = random(-tspeed, tspeed);
    translatediry = random(-tspeed, tspeed);
    translatex = width/2;
    translatey = height/2;
    animationspeedfactor = random(2, 4);
    if (random(10)>8)
    {
      isfast = true;
      animationspeedfactor = random(30, 40);
    }
    resettime = millis();
    drawtriangle = false;
    drawrect = false;
    drawellipse = false;
    if (random(1) > 0.5f)
    {
      drawtriangle = true;
    }
    if (random(1) > 0.5f)
    {
      drawrect = true;
    }
    if (random(1) > 0.5f)
    {
      drawellipse = true;
    }
    if (drawtriangle == false && drawellipse == false && drawrect == false)
    {
      drawrect = true;
    }
    colormode = PApplet.parseInt(random(0, 5));
    angle = 0;
    rectanglewidth = random(width/10, width/2);
    rectangleheight = random(width/10, width/2);
    trix1 = random(-height/2, height/2);
    trix2 = random(-height/2, height/2);
    triy1 = random(-height/2, height/2);
    triy2 = random(-height/2, height/2);
    ellipsewidth = random(width/10, width/2);
    ellipseheight = random(width/10, width/2);
    greatestwidth = 0;
    if (rectanglewidth>greatestwidth && drawrect)
    {
      greatestwidth = rectanglewidth;
    }
    if ((trix1*2)>greatestwidth && drawtriangle)
    {
      greatestwidth = trix1;
    }
    if ((trix2*2)>greatestwidth && drawtriangle)
    {
      greatestwidth = trix2*2;
    }
    if ((triy1*2)>greatestwidth && drawtriangle)
    {
      greatestwidth = (triy1*2);
    }
    if ((triy2*2)>greatestwidth && drawtriangle)
    {
      greatestwidth = triy2*2;
    }
    if (ellipsewidth > greatestwidth && drawellipse)
    {
      greatestwidth = ellipsewidth;
    }
    if (ellipseheight > greatestwidth && drawellipse)
    {
      greatestwidth = ellipseheight;
    }
    if (rectangleheight > greatestwidth && drawrect)
    {
      greatestwidth = rectangleheight;
    }
    widthfactor = random(0.7f, 1);
    heightfactor = random(0.7f, 0.99f);
    rectcolormode = PApplet.parseInt(random(0, 6));
    ellipsecolormode = PApplet.parseInt(random(0, 6));
    tricolormode = PApplet.parseInt(random(0, 6));
    rectotherc = random(50, 255);
    ellipseotherc = random(50, 255);
    triotherc = random(50, 255);
    if (random(1)>0.5f)
    {
      rectcolorchangefactor = random(40, 90);
      ellipsecolorchangefactor = random(40, 90);
      tricolorchangefactor = random(40, 90);
    } else
    {
      rectcolorchangefactor = random(10, 30);
      ellipsecolorchangefactor = random(10, 30);
      tricolorchangefactor = random(10, 30);
    }
    if (random(0, 25) > 24)
    {
      iswhite = true;
    } else
    {
      iswhite = false;
    }
    if (random(1)>0.5f)
    {
      backgroundc = 0;
    } else
    {
      backgroundc = color(random(0, 255), random(0, 255), random(0, 255));
    }
  }

  public void strokefactorandmode(float f, int mode, float otherc, float colorchangefactor)
  {
    float colorf = (f*colorchangefactor)%255;
    if (mode == 0)
    {
      stroke(colorf, otherc, 0);
    } else if (mode == 1)
    {
      stroke(colorf, 0, otherc);
    } else if (mode == 2)
    {
      stroke(0, colorf, otherc);
    } else if (mode == 3)
    {
      stroke(otherc, colorf, 0);
    } else if (mode == 4)
    {
      stroke(otherc, 0, colorf);
    } else if (mode == 5)
    {
      stroke(0, otherc, colorf);
    }
    if (iswhite)
    {
      stroke(255);
    }
  }

  public void key_released()
  {
    reset();
  }
  public void mouse_released()
  {
    reset();
  }
}
class Zig
{
  float x, y, speedX, speedY, thickness;
  String type;
  int c;
  float squarebound = 10;
  boolean rainbow;

  Zig(float tempx, float tempy, float tempsX, float tempsY, String temptype, float tempthickness, int tempc, float sb)
  {
    x = tempx;
    y = tempy;
    speedX = tempsX;
    speedY = tempsY;
    type = temptype;
    thickness = tempthickness;
    c = tempc;
    squarebound = sb;
    if(random(0, 20)>19)
    {
      rainbow = true;
    }
  }

  public void drawOne()
  {
    float oldx=x;
    float oldy=y;
    if (x+(thickness/2)>width)
    {
      randomDir(-10, 0, 1);
      speedX=randDirX;
      speedY=randDirY;
    }
    if (x-(thickness/2)<0)
    {
      randomDir(0, 10, 1);
      speedX=randDirX;
      speedY=randDirY;
    }
    if (y+(thickness/2)>height)
    {
      randomDirY(-10, 0, 1);
      speedX=randDirX;
      speedY=randDirY;
    }
    if (y-(thickness/2)<0)
    {
      randomDirY(0, 10, 1);
      speedX=randDirX;
      speedY=randDirY;
    }
    if(rainbow)
    {
      stroke(color(random(0, 255), random(0, 255), random(0, 255)));
    }else
    {
      stroke(c);
    }
    if(type=="zig-zag" && PApplet.parseInt(random(0,10))==1)
    {
      randomDir(-10, 10, 1);
      speedX=randDirX;
      speedY=randDirY;
    }
    if(type=="smooth")
    {
      if(PApplet.parseInt(random(0, 2))==1)
      {
        speedX+=2;
        speedY-=2;
      }else
      {
        speedY+=2;
        speedX-=2;
      }
    }
    strokeWeight(thickness);
    if(type=="square")
    {
      if(PApplet.parseInt(random(0,2))==1)
      {
        speedX=(random(-squarebound,squarebound));
        speedY=0;
      }else
      {
        speedY=(random(-squarebound,squarebound));
        speedX=0;
      }
    }
    x+=speedX;
    y+=speedY;
    if(type == "square")
    {
      if(x>width)
      {
        x = width;
      }
      if(x<0)
      {
        x = 0;
      }
      if(y<0)
      {
        y = 0;
      }
      if(y>height)
      {
        y = height;
      }
    }
    line(x, y, oldx, oldy);
  }
}
public void randomDir(float low, float heigh, float speed)
{
  float r = random(low, heigh)/speed;
  randDirX = r;
  if (PApplet.parseInt(random(2))==1)
  {
    randDirY = ((-(abs(low)+abs(heigh)))/speed)-abs(r);
  } else
  {
    randDirY = ((abs(low)+abs(heigh))/speed)-abs(r);
  }
}

public void randomDirY(float low, float heigh, float speed)
{
  float r = random(low, heigh)/speed;
  randDirY = r;
  if (PApplet.parseInt(random(2))==1)
  {
    randDirX = ((-(abs(low)+abs(heigh)))/speed)-abs(r);
  } else
  {
    randDirX = ((abs(low)+abs(heigh))/speed)-abs(r);
  }
}
public int randomColor()
{
  int r = PApplet.parseInt(random(-1, 5));
  if (r==4)
  {
    return color(255, 0, 0);
  } else if (r==3)
  {
    return color(255, 255, 0);
  } else if (r==2)
  {
    return color(0, 255, 0);
  } else if (r==1)
  {
    return color(255, 0, 255);
  } else if(r==-1)
  {
    return color(240, 100, 0);
  }else
  {
    return color(0, 0, 255);
  }
}

public int randomColorGhost()
{
  int r = PApplet.parseInt(random(-1, 5));
  if (r==4)
  {
    return color(255, 0, 0, random(100, 256));
  } else if (r==3)
  {
    return color(255, 255, 0, random(100, 256));
  } else if (r==2)
  {
    return color(0, 255, 0, random(100, 256));
  } else if (r==1)
  {
    return color(255, 0, 255, random(100, 256));
  } else if(r==-1)
  {
    return color(240, 100, 0, random(100, 256));
  }else
  {
    return color(0, 0, 255, random(100, 256));
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "screensaver_variety" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
